package com.hotel.dao;

public class RoomDao {
	
}
