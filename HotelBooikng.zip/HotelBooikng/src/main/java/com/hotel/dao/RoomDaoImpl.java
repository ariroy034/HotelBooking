package com.hotel.dao;

public class RoomDaoImpl {

}
