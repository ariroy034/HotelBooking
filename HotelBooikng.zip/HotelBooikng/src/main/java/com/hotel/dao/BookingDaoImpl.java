package com.hotel.dao;

import java.util.List;

import com.hotel.model.Booking;

public class BookingDaoImpl implements BookingDao {

	@Override
	public List<Booking> showBooking() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String AddBooking() {
		// TODO Auto-generated method stub
		return null;
	}

}
