package com.hotel.dao;

import java.util.List;

import com.hotel.model.Booking;

public interface BookingDao {
	
	public List<Booking> showBooking();
	public String AddBooking();
	
}
