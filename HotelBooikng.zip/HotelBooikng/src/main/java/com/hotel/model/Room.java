package com.hotel.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Room {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int RO_ID;
	private String RO_ROOM_NUMBER;
	@OneToMany(mappedBy="room")
	private List<Booking> bookingList=new ArrayList<Booking>();
	public List<Booking> getBookingList() {
		return bookingList;
	}
	public void setBookingList(List<Booking> bookingList) {
		this.bookingList = bookingList;
	}
	public int getRO_ID() {
		return RO_ID;
	}
	public void setRO_ID(int rO_ID) {
		RO_ID = rO_ID;
	}
	public String getRO_ROOM_NUMBER() {
		return RO_ROOM_NUMBER;
	}
	public void setRO_ROOM_NUMBER(String rO_ROOM_NUMBER) {
		RO_ROOM_NUMBER = rO_ROOM_NUMBER;
	}
}
