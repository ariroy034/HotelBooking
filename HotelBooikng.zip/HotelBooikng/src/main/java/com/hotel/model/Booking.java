package com.hotel.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Booking {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int RB_ID;
	private Date RO_DATE;
	private char RB_BOOKED;
	public int getRB_ID() {
		return RB_ID;
	}
	public void setRB_ID(int rB_ID) {
		RB_ID = rB_ID;
	}
	public Date getRO_DATE() {
		return RO_DATE;
	}
	public void setRO_DATE(Date rO_DATE) {
		RO_DATE = rO_DATE;
	}
	public char getRB_BOOKED() {
		return RB_BOOKED;
	}
	public void setRB_BOOKED(char rB_BOOKED) {
		RB_BOOKED = rB_BOOKED;
	}
	public Room getRoom() {
		return room;
	}
	public void setRoom(Room room) {
		this.room = room;
	}
	@ManyToOne
	@JoinColumn
	Room room;
}
